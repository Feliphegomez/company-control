# The database update has been implemented in org.jivesoftware.database.bugfix.OF33.java
# Update version
UPDATE ofVersion SET version = 21 WHERE name = 'openfire';
